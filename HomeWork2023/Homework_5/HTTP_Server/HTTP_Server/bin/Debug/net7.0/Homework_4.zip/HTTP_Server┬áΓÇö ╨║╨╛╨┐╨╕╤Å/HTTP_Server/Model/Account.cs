﻿using System;
namespace HTTP_Server.Model
{
	public class Account
	{
		public string Email { get; set; }

		public string password { get; set; }
	}
}

