import React from "react";
import "./BreedingStyle.css";

const Breeding = () => {
  return (
    <div className="hdr">
      <h1 className="lb_h">Breeding</h1>
    </div>
  );
};

export default Breeding;